class Pizza{
    Id;
    Nombre;
    libreGluten;
    Importe;
    Descripcion;
}
export default Pizza;